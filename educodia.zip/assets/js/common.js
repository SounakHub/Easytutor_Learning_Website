function registr(){
    location.assign('subscribtion.html');
}